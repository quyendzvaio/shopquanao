# Chay du an bang Docker

## Yeu cau

- Docker
- Docker Compose

## Chay lan dau

```bash
docker compose up -d --build
```

Docker se tu dong:

- build PHP 8.2 + Apache
- cai extension `pdo_mysql`
- tao database `shop_db`
- import du lieu tu `sql/shop_db.sql`
- start app ngay khi database container bat dau chay; app tu retry ket noi database trong vai giay dau

## Dia chi truy cap

- Website: http://localhost:8080

phpMyAdmin khong chay mac dinh de tranh khoi dong cham. Khi can dung:

```bash
docker compose --profile tools up -d
```

Sau do mo:

- phpMyAdmin: http://localhost:8081

## Tai khoan

Admin website:

```text
admin
123456
```

Hoac:

```text
admin@gmail.com
123456
```

phpMyAdmin:

```text
server: db
user: root
password: root_pass
```

Tai khoan database cho app:

```text
database: shop_db
user: shop_user
password: shop_pass
```

## Dung container

```bash
docker compose down
```

## Chay lai nhanh sau lan dau

Neu khong doi Dockerfile, chi can:

```bash
docker compose up -d
```

Lenh nay dung lai image va volume database da co, nen nhanh hon nhieu so voi build/import lai.

## Reset database va import lai tu dau

Lenh nay xoa volume database hien tai:

```bash
docker compose down -v
docker compose up -d --build
```
