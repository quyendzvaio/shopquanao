<?php
session_start();
require_once 'config/db.php';

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = $_POST['full_name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$note = $_POST['note'] ?? '';

try {
    $pdo->beginTransaction(); // Bắt đầu giao dịch để đảm bảo an toàn dữ liệu

    // 1. Tính tổng tiền giỏ hàng
    $stmt = $pdo->prepare("SELECT product_id, quantity FROM cart WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $cart_items = $stmt->fetchAll();
    
    $total_price = 0;
    foreach($cart_items as $item) {
        $p_stmt = $pdo->prepare("SELECT price FROM products WHERE id = ?");
        $p_stmt->execute([$item['product_id']]);
        $price = $p_stmt->fetchColumn();
        $total_price += $price * $item['quantity'];
    }

    // 2. Tạo đơn hàng trong bảng orders
    $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_price, status, created_at) VALUES (?, ?, 'pending', NOW())");
    $stmt->execute([$user_id, $total_price]);
    $order_id = $pdo->lastInsertId();

    // 3. Chuyển từng món từ giỏ hàng sang order_items
    foreach($cart_items as $item) {
        $p_stmt = $pdo->prepare("SELECT price FROM products WHERE id = ?");
        $p_stmt->execute([$item['product_id']]);
        $current_price = $p_stmt->fetchColumn();

        $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        $stmt->execute([$order_id, $item['product_id'], $item['quantity'], $current_price]);
    }

    // 4. Xóa giỏ hàng của user sau khi đặt thành công
    $stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
    $stmt->execute([$user_id]);

    $pdo->commit(); // Hoàn tất lưu dữ liệu
    echo "<script>alert('Đặt hàng thành công! Fashion Shop sẽ liên hệ bạn sớm nhất.'); window.location.href='index.php';</script>";

} catch (Exception $e) {
    $pdo->rollBack(); // Nếu có lỗi thì hủy bỏ các bước trên
    die("Lỗi đặt hàng: " . $e->getMessage());
}